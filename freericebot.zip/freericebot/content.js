setInterval(function() {
    problem = document.getElementsByClassName("card-title").item(0).innerHTML;
    pr = problem.replace('x', '');
    numbers = pr.split(' ');
    let number1 = numbers[0] | 0;
    let number10 = numbers[2] | 0;
    let answer = number1 * number10;
    table = document.getElementsByClassName("card-button");

    a = table.item(0)
    b = table.item(1)
    c = table.item(2)
    d = table.item(3)

    a_val = table.item(0).innerHTML | 0;
    b_val = table.item(1).innerHTML | 0;
    c_val = table.item(2).innerHTML | 0;
    d_val = table.item(3).innerHTML | 0;

    if(answer == a_val) { 
        a.click(); 
    }

    else if(answer == b_val) {
        b.click(); 
    }

    else if(answer == c_val) {
        c.click(); 
    }

    else { 
        d.click(); 
    }
}, 500);